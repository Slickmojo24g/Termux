# Termux-added-keys
Termux commands
